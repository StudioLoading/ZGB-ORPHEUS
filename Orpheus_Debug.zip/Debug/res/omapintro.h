#ifndef MAP_omapintro_H
#define MAP_omapintro_H
#define omapintroWidth 40
#define omapintroHeight 78
#include "MapInfo.h"
extern unsigned char bank_omapintro;
extern struct MapInfo omapintro;
#endif
