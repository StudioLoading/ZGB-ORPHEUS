#ifndef TILES_hudt_H
#define TILES_hudt_H
#include "TilesInfo.h"
extern const void __bank_hudt;
extern struct TilesInfo hudt;
#endif
