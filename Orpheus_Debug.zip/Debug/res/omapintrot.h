#ifndef TILES_omapintrot_H
#define TILES_omapintrot_H
#define omapintrotCGBPal0c0 32767
#define omapintrotCGBPal0c1 6143
#define omapintrotCGBPal0c2 2784
#define omapintrotCGBPal0c3 5344

#include "TilesInfo.h"
extern const void __bank_omapintrot;
extern struct TilesInfo omapintrot;
#endif
