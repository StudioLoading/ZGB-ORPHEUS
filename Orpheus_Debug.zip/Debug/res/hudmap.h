#ifndef MAP_hudmap_H
#define MAP_hudmap_H
#define hudmapWidth 20
#define hudmapHeight 2
#include "MapInfo.h"
extern unsigned char bank_hudmap;
extern struct MapInfo hudmap;
#endif
